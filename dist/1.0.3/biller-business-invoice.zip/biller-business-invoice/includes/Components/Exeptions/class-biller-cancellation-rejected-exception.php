<?php

namespace Biller\Components\Exceptions;

use Exception;

class Biller_Cancellation_Rejected_Exception extends Exception {

}