<?php

namespace Biller\Components\Exceptions;

use Exception;

class Biller_Capture_Rejected_Exception extends Exception {

}
