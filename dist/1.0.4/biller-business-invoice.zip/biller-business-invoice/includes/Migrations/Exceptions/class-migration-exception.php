<?php


namespace Biller\Migrations\Exceptions;

use Exception;

/**
 * Class Migration_Exception
 *
 * @package Biller\Migrations\Exceptions
 */
class Migration_Exception extends Exception {


}
